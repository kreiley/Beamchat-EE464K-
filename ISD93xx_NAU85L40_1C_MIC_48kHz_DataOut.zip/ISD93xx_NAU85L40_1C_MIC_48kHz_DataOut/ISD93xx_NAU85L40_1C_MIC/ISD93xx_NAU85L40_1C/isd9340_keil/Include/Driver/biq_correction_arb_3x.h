// Arbitrary response 6th order Biquad (DF2TSOS)
// Coefficient b0 stage 1 = 0x01e87	 ( 7815)	(0.119247) 
// Coefficient b1 stage 1 = 0x01e73	 ( 7795)	(0.118942) 
// Coefficient b2 stage 1 = 0x0007d	 (  125)	(0.001907) 
// Coefficient a0 stage 1 = 0x6ce82	 (-78206)	(-1.193329) 
// Coefficient a1 stage 1 = 0x06ef9	 (28409)	(0.433487) 
// Coefficient b0 stage 2 = 0x0bed2	 (48850)	(0.745392) 
// Coefficient b1 stage 2 = 0x745fb	 (-47621)	(-0.726639) 
// Coefficient b2 stage 2 = 0x0bed1	 (48849)	(0.745377) 
// Coefficient a0 stage 2 = 0x6e4f7	 (-72457)	(-1.105606) 
// Coefficient a1 stage 2 = 0x0f1ea	 (61930)	(0.944977) 
// Coefficient b0 stage 3 = 0x06d42	 (27970)	(0.426788) 
// Coefficient b1 stage 3 = 0x7bc36	 (-17354)	(-0.264801) 
// Coefficient b2 stage 3 = 0x06d37	 (27959)	(0.426620) 
// Coefficient a0 stage 3 = 0x6e1b1	 (-73295)	(-1.118393) 
// Coefficient a1 stage 3 = 0x0bf3d	 (48957)	(0.747025) 
const int32_t biq_correction_3x[15] = {
7815, 
7795, 
125, 
-78206, 
28409, 
48850, 
-47621, 
48849, 
-72457, 
61930, 
27970, 
-17354, 
27959, 
-73295, 
48957, 
};
// filter_coeff[0] = 7815; 
// filter_coeff[1] = 7795; 
// filter_coeff[2] = 125; 
// filter_coeff[3] = -78206; 
// filter_coeff[4] = 28409; 
// filter_coeff[5] = 48850; 
// filter_coeff[6] = -47621; 
// filter_coeff[7] = 48849; 
// filter_coeff[8] = -72457; 
// filter_coeff[9] = 61930; 
// filter_coeff[10] = 27970; 
// filter_coeff[11] = -17354; 
// filter_coeff[12] = 27959; 
// filter_coeff[13] = -73295; 
// filter_coeff[14] = 48957; 
